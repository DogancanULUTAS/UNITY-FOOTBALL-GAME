﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Top : MonoBehaviour {

	// Use this for initialization

	public AudioClip[] sesler;

	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}


	void OnCollisionEnter(Collision nesne){
		if(nesne.gameObject.tag=="Direk"){
			GetComponent<AudioSource> ().PlayOneShot (sesler [1]);


		}
			
			

}


	void OnCollisionExit(Collision nesne){
		if (nesne.gameObject.tag == "Duvar") {
			GetComponent<AudioSource> ().PlayOneShot (sesler [2]);


		}

	}
}