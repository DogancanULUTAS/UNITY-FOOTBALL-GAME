﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Anamen : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void butonlar(int deger){
		if (deger == 0) {
			Application.LoadLevel ("can1");
		} 

	}
}
