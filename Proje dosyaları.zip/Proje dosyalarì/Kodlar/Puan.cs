﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Puan : MonoBehaviour {

	// Use this for initialization
	public float puan;
	public Oyun oyun;
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision nesne){
		if (nesne.gameObject.CompareTag ("Top")) {
			oyun.PuanEkle (puan);
		}

	}

}
