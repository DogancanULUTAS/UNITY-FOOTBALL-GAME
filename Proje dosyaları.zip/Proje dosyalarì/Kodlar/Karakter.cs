﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Karakter : MonoBehaviour {



	public bool top;


	public GameObject topobj;


	public float sut1, sut2, hava1, hava2;
	void Start () {
		
	}


	
	// Update is called once per frame
	void Update () {

		if(top) {

			if(Input.GetMouseButtonDown(0)) {

				topobj.GetComponent<Rigidbody> ().velocity = transform.TransformDirection (new Vector3 (0, 0, 7));
				topobj.GetComponent<AudioSource> ().PlayOneShot (topobj.GetComponent<Top> ().sesler [0]);
			}

			if(Input.GetMouseButtonDown(1)) {

				topobj.GetComponent<Rigidbody> ().velocity = transform.TransformDirection (new Vector3 (0, Random.Range(hava1,hava2), Random.Range(sut1,sut2)));
				topobj.GetComponent<AudioSource> ().PlayOneShot (topobj.GetComponent<Top> ().sesler [0]);
	}

		}
			
}




}
