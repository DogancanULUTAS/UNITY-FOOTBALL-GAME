﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ayakt : MonoBehaviour {


	void Start () {
		
	}
	

	void Update () {
		
	}


	void OnTriggerEnter(Collider nesne){
		if (nesne.gameObject.tag == "Top") {
			transform.root.gameObject.GetComponent<Karakter> ().top = true;
		}

	}


	void OnTriggerStay(Collider nesne){
		if (nesne.gameObject.tag == "Top") {
			transform.root.gameObject.GetComponent<Karakter> ().top = true;
		}

	}

	void OnTriggerExit(Collider nesne){
		if(nesne.gameObject.tag == "Top") {
			transform.root.gameObject.GetComponent<Karakter> ().top = false;	

		}

	}
}
