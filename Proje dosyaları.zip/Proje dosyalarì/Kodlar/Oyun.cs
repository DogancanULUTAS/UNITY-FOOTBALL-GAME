﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Oyun : MonoBehaviour {

	// Use this for initialization

	public float toplampuan;
	public Text Puan;
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}


	public void PuanEkle(float puan){

		toplampuan += puan;
		Puan.text = "Puan : " + toplampuan;


	}

}
